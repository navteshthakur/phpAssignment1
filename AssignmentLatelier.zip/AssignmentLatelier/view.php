<?php
	require_once('database.php');
	$res = $database->read();
    $res1 = $database->read1();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Navtesh Thakur" />
	<meta name="description" content="PHP Assignment 1">
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
    crossorigin="anonymous" referrerpolicy="no-referrer">
    <script src="javaScript/loginjs.js" defer></script>
    <title>View | L'Atelier</title>
</head>
<body class="viewbg">
    <header>
        <?php include('C:\xampp\htdocs\AssignmentLatelier\includes\nav.php'); ?>
    </header>
    <br>
        <br>
    <main class="view">
        <section>
            <article>
                <table class="t1">
                <tr>
				<th>S.No</th>
				<th>E-mail</th>
				<th>Password</th>
			    </tr>
                <?php

				while($r = mysqli_fetch_assoc($res)){
			?>
					<tr>
						<td><?php echo $r['S.No']; ?></td>
						<td><?php echo $r['email']; ?></td>
						<td><?php echo $r['password']; ?></td>
					</tr>
				<?php
				}
			?>
                </table>
            </article>
            <article>
                <table class="t2">
                <tr>
				<th>PO#</th>
				<th>Generic-ID</th>
				<th>Color</th>
                <th>Size</th>
                <th>Price</th>
                <th>Quantity</th>
			    </tr>
                <?php

				while($r1 = mysqli_fetch_assoc($res1)){
			?>
					<tr>
						<td><?php echo $r1['purchaseOrder']; ?></td>
						<td><?php echo $r1['gid']; ?></td>
						<td><?php echo $r1['colour'] ?></td>
                        <td><?php echo $r1['size'] ?></td>
                        <td><?php echo $r1['price'] ?></td>
                        <td><?php echo $r1['quantity'] ?></td>
					</tr>
				<?php
				}
			?>
                </table>
            </article>
        </section>
    </main>
    
    <footer>
    <?php include('C:\xampp\htdocs\AssignmentLatelier\includes\footer.php'); ?>
    </footer>
</body>
</html>