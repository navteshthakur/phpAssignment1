<?php
	require_once('database.php');
	$res = $database->read();
    $res1 = $database->read1();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Navtesh Thakur" />
	<meta name="description" content="PHP Assignment 1">
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
    crossorigin="anonymous" referrerpolicy="no-referrer">
    <script src="javaScript/loginjs.js" defer></script>
    <title>View | L'Atelier</title>
</head>
<body class="viewbg">
    <header>
        <?php include('C:\xampp\htdocs\AssignmentLatelier\includes\nav.php'); ?>
    </header>
    <br>
        <br>
    <main class="view">
        <section>
        <?php 
                        include_once ('validate.php');  
                        require_once('database.php');
                        $valid = new validate();
                         if(isset($_POST['b1'])){
							$email = $_POST['email'];
							$password = $_POST['password'];
                            $msg = $valid->checkEmpty($_POST, array('email','password'));
                            $checkEmail = $valid->validEmail($_POST['email']);

                            if($msg != null){
                                echo $msg;
                                echo "<a href='javascript:self.history.back();'>Go Back</a>";
                              }elseif(!$checkEmail){
                                echo '<p>Please provide a valid email.</p>';
                                echo "<a href='javascript:self.history.back();'>Go Back</a>";
                              }else{
							$res   = $database->create($email, $password);
							if($res){
								echo "<p>Successfully inserted data</p>";
							}else{
								echo "<p>Failed to insert data</p>";
							}
						} 
                    }elseif(isset($_POST['b2'])){
							$purchaseOrder = $_POST['purchaseOrder'];
							$gid = $_POST['gid'];
							$colour = $_POST['colour'];
							$size = $_POST['size'];
                            $price = $_POST['price'];
                            $quantity = $_POST['quantity'];
                            $msg = $valid->checkEmpty($_POST, array('purchaseOrder','gid','colour','size','price','quantity'));
                            $checkQuantity = $valid->validQuantity($_POST['quantity']);

                            if($msg != null){
                                echo $msg;
                                echo "<a href='javascript:self.history.back();'>Go Back</a>";
                              }elseif(!$checkQuantity){
                                echo '<p>Please provide a valid quantity.</p>';
                                echo "<a href='javascript:self.history.back();'>Go Back</a>";
                              }else{
							$res1   = $database->create1($purchaseOrder, $gid, $colour, $size, $price, $quantity );
							if($res1){
								echo "<p>Successfully inserted data!</p>";
							}else{
								echo "<p>Failed to insert data</p>";
							}
                        }
					}
					?>
        </section>
    </main>
    
    <footer class="addfoot">
    <?php include('C:\xampp\htdocs\AssignmentLatelier\includes\footer.php'); ?>
    </footer>
</body>
</html>