<nav>
	<ul>
        <li>L'ATELIER<li>
		<li><a href="index.php" title="Go to the Home page">Home</a></li>
		<li><a href="view.php" title="View Inventory">View</a>
	</ul>
</nav>
<hr style="border-top:4.5px solid bisque">