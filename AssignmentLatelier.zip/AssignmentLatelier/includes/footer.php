<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
    crossorigin="anonymous" referrerpolicy="no-referrer">
<hr style="border-top:6px solid rgba(100, 65, 22, 0.796);">
<br>
<br>
<nav class="row">
      <a href="#"><i class="fa-brands fa-instagram" style="color: #666666;"></i></a>
      <a href="#"><i class="fa-brands fa-facebook" style="color: #878787;"></i></a>
      <a href="#"><i class="fa-regular fa-envelope" style="color: #696969;"></i></a>
      <a href="#"><i class="fa-brands fa-linkedin" style="color: #6b6b6b;"></i></a>
</nav>
<br>
    <p class="policies">
      <a href="#">Privacy Policy</a>
      <a href="#">Terms of use</a>
      <a href="#">Developer Information</a>
    </p>
<br>
<p>
    <small>The content of this site is copyright-protected and is the property of L'Atelier LP.</small>
</p>
<p><small>© Copyright 2019-2023 L'Atelier LP. All rights reserved.</small></p>
<br>
<hr style="border-top:6px solid rgba(100, 65, 22, 0.796);">
