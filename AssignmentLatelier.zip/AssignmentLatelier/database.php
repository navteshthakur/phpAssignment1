<?php
class Database{
    private $connection;
    function __construct(){
      $this->connect_db();
    }
    public function connect_db(){
        $this->connection = mysqli_connect('localhost', 'root', '', 'inventorylatelier');
        if(mysqli_connect_error()){
          die("Database Connection Failed" . mysqli_connect_error());
        }
      }
      public function create($email,$password){
        $sql = "INSERT INTO login (email, password) VALUES ('$email', '$password')";
        $res = mysqli_query($this->connection, $sql);
        if($res){
                   return true;
            }
        else{
                  return false;
            }
          }
      public function create1($purchaseOrder,$gid,$colour,$size,$price,$quantity){
        $sql1 = "INSERT INTO inventoryentry (purchaseOrder, gid, colour, size, price,quantity) VALUES ('$purchaseOrder','$gid','$colour','$size','$price','$quantity')";
        $res1 = mysqli_query($this->connection, $sql1);
        if($res1){
          return true;
         }
        else{
         return false;
        }
      }
      public function read(){
        $sql = "SELECT * FROM login";
         $res = mysqli_query($this->connection, $sql);
         return $res;
  }
  public function read1(){
     $sql1 = "SELECT * FROM inventoryentry";
     $res1 = mysqli_query($this->connection, $sql1);
     return $res1;
}
}
$database = new Database();
?>