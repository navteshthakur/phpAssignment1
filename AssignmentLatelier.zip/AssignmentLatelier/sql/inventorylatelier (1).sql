-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 15, 2023 at 03:02 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventorylatelier`
--

-- --------------------------------------------------------

--
-- Table structure for table `inventoryentry`
--

CREATE TABLE `inventoryentry` (
  `purchaseOrder` varchar(255) NOT NULL,
  `gid` varchar(255) NOT NULL,
  `colour` varchar(255) NOT NULL,
  `size` varchar(255) NOT NULL,
  `price` int(255) NOT NULL,
  `quantity` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventoryentry`
--

INSERT INTO `inventoryentry` (`purchaseOrder`, `gid`, `colour`, `size`, `price`, `quantity`) VALUES
('PO#123456789', '854-S23', 'sagesse', '2XS', 100, 0),
('PO#8546546165', '412-F23', 'fieryRed', 'XS', 150, 0),
('PO#456789425', '102-W24', 'richMochaBrown', 'XL', 500, 0),
('PO#188845674', '213-W24', 'cloudWhite', 'L', 450, 45),
('PO#85468585165', '213-F24', 'black', 'XS', 85, 85),
('PO#85468585165', '213-F24', 'black', 'XS', 85, 85),
('PO#85468585165', '213-F24', 'black', 'XS', 85, 85),
('PO#8546544412', '785-S23', 'modernTaupe', 'S', 99, 9),
('PO#8548584556', '213-F24', 'richMochaBrown', 'L', 85, 18),
('PO#12345654654', '273-W23', 'heatherCharcoal', 'S', 500, 10);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `S.No` int(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`S.No`, `email`, `password`) VALUES
(1, 'navtesht@latelier.com', 'navtesh123'),
(2, 'abhishek.thakur@latelier.com', 'abhi852'),
(3, 'sherryCheema21@latelier.com', 'sherwan'),
(4, 'khvfktjsreryay@jbk.mnk', 'jgfyudtrsut'),
(5, 'tanishkasagar@latelier.com', 'tishhsagar999'),
(6, 'u1ditDhillon@latelier.com', 'uditnol789'),
(7, '200554899@latelier.com', 'employeelogin22'),
(8, 'Skaur148@latelier.com', 'san543k'),
(9, 'thnavtesh@latelier.com', 'nthakur567'),
(10, 'jagnoorK@latelier.com', 'jag123noor');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`S.No`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `S.No` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
