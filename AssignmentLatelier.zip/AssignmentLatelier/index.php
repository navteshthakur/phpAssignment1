<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Navtesh Thakur">
	<meta name="description" content="PHP Assignment 1: There are 2 forms: one takes the user entry and the other takes the entry for inventory.">
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
    crossorigin="anonymous" referrerpolicy="no-referrer">
    <script src="javaScript/loginjs.js" defer></script>
    <title>Home | L'Atelier</title>
</head>
<body>
    <header>
        <?php include('C:\xampp\htdocs\AssignmentLatelier\includes\nav.php');?>
    </header>
    <main>
        <section class="flip">
            <div class="inner-box" id="card" >
                <article class="one" style="background-image:url('images/backf.jpg') ;">
                    <form  action="add.php" method="post" name="form1">
                        <fieldset>
                            <h2><strong>LOGIN</strong></h2>
                            <label for="email">E-mail</label>
                            <input type="email" id="email" name="email" placeholder="abc@latelier.com" required>
                            <label for="password">Password</label>
                            <input type="password" id="password" name="password" required>
                            <button type="submit" name="b1">Login</button>
                            <p>To update inventory, <span class="btn" onclick="openInventory()">click here.</span></p>
                        </fieldset>
                    </form>
                </article>
                <article class="two"  style="background-image:url('images/backf.jpg') ;">
                    <form action="add.php" method="post" name="form2">
                        <fieldset>
                            <h2><strong>UPDATE INVENTORY</strong></h2>
                            <label for="purchaseOrder">Purchase Order</label>
                            <input type="text" id="purchaseOrder" name="purchaseOrder" placeholder="PO#" required>
                            <label for="gid">Generic ID</label>
                            <input type="text" id="gid" name="gid">
                            <label for="colour">Colour</label>
                            <select id="colour" name="colour">
                                <option value="sagesse">Sagesse</option>
                                <option value="fieryRed">Fiery Red</option>
                                <option value="heatherCharcoal">Heather Charcoal</option>
                                <option value="modernTaupe">Modern Taupe</option>
                                <option value="richMochaBrown">Rich Mocha Brown</option>
                                <option value="cloudWhite">Cloud White</option>
                                <option value="black">Black</option>
                                <option value="mulberryPurple">Mulberry Purple</option>
                            </select>
                            <label for="size">Size</label>
                            <select id="size" name="size">
                                <option value="2XS">2XS</option>
                                <option value="XS">XS</option>
                                <option value="S">S</option>
                                <option value="L">L</option>
                                <option value="XL">XL</option>
                                <option value="2XL">2XL</option>
                            </select>
                             <label for="price">Price</label>
                            <input type="number" id="price" name="price">
                            <label for="quantity">Quantity</label>
                            <input type="text" id="quantity" name="quantity">
                            <button type="submit" name="b2">Update</button>
                            <p>To log-in, <span class="btn" onclick="openLogin()"> click here.</span></p>
                        </fieldset>
                    </form>
                    
                </article>
            </div>
        </section>
        <section class="info">
            <figure>
                <img src="images//clothes.gif" alt="background" height=319 width=319>
            </figure>
            <p>"Beauty begins the moment you decide to be yourself."<em>-L'Atelier</em></p>
        </section>
    </main>
    <footer>
        <?php include('C:\xampp\htdocs\AssignmentLatelier\includes\footer.php'); ?>
    </footer>
</body>
</html>